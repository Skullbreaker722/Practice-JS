const express = require('express');
const app = express();
const expressLayouts = require('express-ejs-layouts');

app.set('view engine', 'ejs');
app.use(expressLayouts);
app.set('views', './views');

app.get('/', (req, res) => {
  res.render('pages/scroll');
});

app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
